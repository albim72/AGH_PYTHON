"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import Flask,render_template,request,json
from flask.scaffold import _matching_loader_thinks_module_is_package
from flaskext.mysql import MySQL
from flask_bazamysql import app
from werkzeug.security import generate_password_hash


mysql = MySQL()

#konfiguracja MySQL
app.config['MYSQL_DATABASE_USER']='root'
app.config['MYSQL_DATABASE_PASSWORD']='abc123'
app.config['MYSQL_DATABASE_DB']='logindatabase'
app.config['MYSQL_DATABASE_HOST']='localhost'
mysql.init_app(app)

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,


    )

@app.route('/showsignup')
def showsignup():
    return render_template('signup.html')

@app.route('/signup', methods = ['POST','GET'])
def signup():
    try:
        _name = request.form['inputName']
        _email = request.form['inputEmail']
        _password = request.form['inputPassword']

        if _name and _email and _password:

            conn = mysql.connect()
            cursor = conn.cursor()

            _hashed_password = generate_password_hash(_password)
            cursor.callproc('sp_createUser',(_name,_email,_hashed_password))
            data = cursor.fetchall()



            if len(data) is 0:
                conn.commit()
                return json.dumps({'message':'User created successfully!'})
                
            else:
                return json.dumps({'error':str(data[0])})



        else:
            return json.dumps({'html':'<span>Wypelnij wszystkie pola!</span>'})
            
        
    except Exception as e:
        return json.dumps({'error':str(e)})
    else:
        cursor.close()
        conn.close()



    

